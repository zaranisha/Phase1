package assisted3;


import java.io.FileWriter;
import java.io.IOException;  
public class Write
{
    public static void main(String[] args) {  
    try {  
        FileWriter fwrite = new FileWriter("demo.txt");  
        fwrite.write("Written using FileWriter!!!");   
        fwrite.close(); 
        } catch (IOException e) {  
        System.out.println("Error While Writing!!!");  
        e.printStackTrace();  
        }  
    }  
}  