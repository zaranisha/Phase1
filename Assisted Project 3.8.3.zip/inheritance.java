package assisted3;

import java.util.Scanner;
class GetInputA{
	int a,b;
	Scanner sc = new Scanner(System.in);
	public void getInputA() {
		System.out.println("Enter First Value");
		a = sc.nextInt();
	}
}
class GetInputB extends GetInputA{
	public void getInputB() {
		System.out.println("Enter Second Value");
		b = sc.nextInt();
	}
}

class ProcessInput extends GetInputB{
	int c;
	public void add() {
		c = a+b;
	}
}

class ShowOutputValue extends ProcessInput{
	public void showOutput() {
		System.out.println("the output for the add problem  " +c);
	}}
public class inheritance {

	public static void main(String[] args) {
		ShowOutputValue s=new ShowOutputValue();
		s.getInputA();
        s.getInputB();
        s.add();
        s.showOutput();
	}

}
