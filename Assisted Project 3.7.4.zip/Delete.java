package assisted3;



import java.io.File;   
public class Delete
{
     public static void main(String[] args)
     {  
        File fdel = new File("demo.txt");   
        if (fdel.delete())
        { 
            System.out.println(fdel.getName()+ " is deleted successfully.");  
        }
        else 
        {  
            System.out.println("Could Not Delete File");  
        }
    }
}