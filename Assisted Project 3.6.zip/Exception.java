package assisted3;

public class Exception {

	public static void main(String args[]) {
		
		try{
			int value=0;
			
			value = 10/0;
			System.out.println(value);
			
		}
		catch(ArithmeticException e) {
			System.out.println("An error occured : "+e.getMessage());
		}
		finally {
			System.out.println("Program Execution Completed");
			
		}
	}
	}