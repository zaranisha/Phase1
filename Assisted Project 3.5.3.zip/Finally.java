package assisted3;

public class Finally 
{
  public static void main (String[]args)
  {
	  @SuppressWarnings("unused")
	int a=45,b=0,rs=0;
      try
      {
          rs = a / b;
      }
      catch(ArithmeticException Ex)
    {
      System.out.println ("error: the number cant divide by zero");
    }
    finally
    {
      System.out.println ("in finally");
    }
    System.out.println ("after try catch finally");
  }
}