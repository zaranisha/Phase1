package assisted3;


interface student1 {
	
	void tutor();
    void id1(); 
    void id2();
}

interface student2 {

	// default void id2() {
		 
	// }
}

class Tutor implements student1, student2 {
	public void tutor() {
		System.out.println("The tutor is for JAVA");
	}
	public void id1() {
		System.out.println("The student id is SID1");
	}
	public  void id2() {
		System.out.println("The student id is SID2");
	}
}

public class Daimond {

	public static void main(String[] args) {
		Tutor t=new Tutor();
		t.tutor();
		t.id1();
        t.id2();
	}

}

