package assisted3;

public class Multithread implements Runnable{
	
	public static int myCount = 0;
    public Multithread(){
         
    }
    public void run() {
        while(Multithread.myCount <= 10){
            try{
                System.out.println("Expl Thread: "+(++Multithread.myCount));
                Thread.sleep(100);
            } catch (InterruptedException iex) {
                System.out.println("Exception in thread: "+iex.getMessage());
            }
        }
    } 
    public static void main(String a[]){
        System.out.println("Starting Main Thread...");
        Multithread mrt = new Multithread();
        Thread t = new Thread(mrt);
        t.start();
        while(Multithread.myCount <= 10){
            try{
                System.out.println("Main Thread: "+(++Multithread.myCount));
                Thread.sleep(100);
            } catch (InterruptedException iex){
                System.out.println("Exception in main thread: "+iex.getMessage());
            }
        }
        System.out.println("End of Main Thread...");
    }


}
