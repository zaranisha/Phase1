package assisted3;

public class Class
{  
    String name; 
    String place; 
    int age; 
    String color; 
    public Class(String name, int age,String place) 
    { 
        this.name = name; 
        this.place= place; 
        this.age = age; 
    
    } 
    public String getName() 
    { 
        return name; 
    } 
    public String getPlace() 
    { 
        return place; 
    } 
    public int getAge() 
    { 
        return age; 
    } 
    
    @Override
    public String toString() 
    { 
        return("Hi my name is "+ this.getName()+ ".\n i am  " + this.getAge()+" years old  and i am living in "+ this.getPlace() + "."); 
    } 
    public static void main(String[] args) 
    { 
    	Class scott = new Class("zara", 15,"chennai"); 
        System.out.println(scott.toString()); 
    } 
}
